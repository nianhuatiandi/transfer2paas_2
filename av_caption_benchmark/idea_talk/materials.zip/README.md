# 教师汇报配套素材

- [播放 8 秒羽毛球视频](badminton_lift_31679122798_first8s.mp4)
- [查看立定跳远视频](standing_long_jump_1039046118_0-7s.mp4)
- [逐页讲稿](av_caption_benchmark/idea_talk/speaker-notes.md)
- [逐项评分报告](av_caption_benchmark/idea_talk/pilot/report.md)
- [参考事件及共现区间](av_caption_benchmark/idea_talk/pilot/gt.json) 和 [模型证据](av_caption_benchmark/idea_talk/pilot/scores.json)
- [原始模型描述](badminton_captions/) 和 [关键帧](av_caption_benchmark/idea_talk/assets/)
- [术语词典和手册页码](av_caption_benchmark/idea_talk/pilot/badminton_vocabulary_prompt.txt)
- [Qwen 专用提示词的早期输出](av_caption_benchmark/qwen3.8_omni_results/20261122_212122/badminton_response.txt)

JSON 中的文件路径均以本包的顶层为起点。案例为单片试评，正式专家复核与 300 条规模的数据建设仍在计划中。源仓库的汇报目录提供 PPT 和静态 PDF。[汇报主页](https://github.com/nianhuatiandi/transfer2paas_2/tree/main/av_caption_benchmark/idea_talk)
